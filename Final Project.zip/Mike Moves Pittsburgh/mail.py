from flask import Flask, render_template, request, redirect, url_for
import psycopg2

app = Flask(__name__)

# PostgreSQL database connection details
db_params = {
    'dbname': 'your_dbname',
    'user': 'your_dbuser',
    'password': 'your_dbpassword',
    'host': 'localhost',
    'port': '5432'
}

def get_db_connection():
    conn = psycopg2.connect(**db_params)
    return conn

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/submit', methods=['POST'])
def submit():
    # Get data from form
    first_name = request.form['first_name']
    last_name = request.form['last_name']
    current_address = request.form['current_address']
    city = request.form['city']
    state = request.form['state']
    zip_code = request.form['zip_code']
    wants_phone_call = 'wants_phone_call' in request.form

    # Insert data into the database
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute("""
        INSERT INTO customer_subscriptions (first_name, last_name, current_address, city, state, zip_code, wants_phone_call)
        VALUES (%s, %s, %s, %s, %s, %s, %s)
    """, (first_name, last_name, current_address, city, state, zip_code, wants_phone_call))
    conn.commit()
    cur.close()
    conn.close()

    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)
