function calculateCost() {
    const distanceRange = document.getElementById("distance").value;
    const numMen = document.getElementById("men").value;
    const pounds = parseFloat(document.getElementById("pounds").value);
    
    if (isNaN(pounds) || pounds < 2500) {
        alert("Please enter a valid weight of at least 2500 lbs.");
        return;
    }

    let pricePerPound = 0;
    let pricePerMile = 0;

    switch (distanceRange) {
        case "40-100":
            pricePerPound = 0.55;
            pricePerMile = 1.00;
            break;
        case "101-200":
            pricePerPound = 0.65;
            pricePerMile = 1.05;
            break;
        case "201-300":
            pricePerPound = 0.75;
            pricePerMile = 1.10;
            break;
        case "301-400":
            pricePerPound = 0.80;
            pricePerMile = 1.15;
            break;
        case "401-500":
            pricePerPound = 0.85;
            pricePerMile = 1.20;
            break;
        case "501-600":
            pricePerPound = 0.90;
            pricePerMile = 1.25;
            break;
        case "601-800":
            pricePerPound = 1.00;
            pricePerMile = 1.50;
            break;
        default:
            alert("Invalid distance range.");
            return;
    }

    const distanceMiles = parseInt(distanceRange.split("-")[1]);

    // Cost Calculation
    const costPerPound = pricePerPound * pounds;
    const costPerMile = pricePerMile * distanceMiles;

    let hourlyRate = 0;
    if (numMen === "2") {
        hourlyRate = 150;
    } else if (numMen === "3") {
        hourlyRate = 170;
    }

    const totalCost = costPerPound + costPerMile + hourlyRate;

    document.getElementById("result").innerHTML = `
        <p>Total Cost Breakdown:</p>
        
            Price per Pound: $${pricePerPound.toFixed(2)} x ${pounds} lbs = $${costPerPound.toFixed(2)}<br><br>
            Price per Mile: $${pricePerMile.toFixed(2)} x ${distanceMiles} miles = $${costPerMile.toFixed(2)}<br><br>
            Hourly Rate for ${numMen} Men: $${hourlyRate}<br><br>
            <strong>Total Cost: $${totalCost.toFixed(2)}</strong>
        
    `;
}