        function openModal(modalId) {
            document.getElementById(modalId).style.display = "block";
        }

        
        function closeModal(modalId) {
            document.getElementById(modalId).style.display = "none";
        }

        
        document.getElementById('product1').addEventListener('click', function() {
            openModal('modal1');
        });

        document.getElementById('product2').addEventListener('click', function() {
            openModal('modal2');
        });

        document.querySelectorAll('.close').forEach(function(closeButton) {
            closeButton.addEventListener('click', function() {
                closeModal(this.getAttribute('data-modal'));
            });
        });


        window.addEventListener('click', function(event) {
            if (event.target.classList.contains('modal')) {
                event.target.style.display = "none";
            }
        });